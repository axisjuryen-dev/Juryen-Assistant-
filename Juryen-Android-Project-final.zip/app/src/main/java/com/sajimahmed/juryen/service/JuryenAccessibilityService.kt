package com.sajimahmed.juryen.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lets Juryen see and interact with the screen of OTHER apps (tap buttons,
 * pick images, etc). This is a starting framework, not a finished automation
 * for every app - each target app's UI is different, so actions like
 * "upload first gallery picture on Facebook" need to be built and tested
 * screen-by-screen against the real app.
 *
 * The user must manually enable this under:
 * Settings > Accessibility > Installed apps > Juryen
 * (Android requires this to be a manual, explicit step - it cannot be
 * auto-granted from inside the app, for security reasons.)
 */
class JuryenAccessibilityService : AccessibilityService() {

    companion object {
        // Lets CommandProcessor reach the running instance.
        var instance: JuryenAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used for now - actions below are triggered on-demand by
        // CommandProcessor rather than reacting to every screen event.
        // For multi-step flows (e.g. "open FB -> tap add photo -> tap
        // first gallery image -> tap post") you would track event.packageName
        // and event.className here to know which screen just appeared, then
        // call the next step automatically.
    }

    fun tapByDescription(description: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return findNodeByAnyText(root, listOf(description))?.let { tapNode(it); true } ?: false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: findEditableNode(root) ?: return false
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findEditableNode(child)?.let { return it }
        }
        return null
    }

    fun swipeVertical(up: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val startY = if (up) dm.heightPixels * 0.75f else dm.heightPixels * 0.25f
        val endY = if (up) dm.heightPixels * 0.25f else dm.heightPixels * 0.75f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 400))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun selectFirstImage(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findFirstClickableImage(root) ?: return false
        tapNode(node)
        return true
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /**
     * Example end-to-end helper: taps the first image in whatever image grid
     * is currently on screen (e.g. a gallery picker), then tries to find and
     * tap a common "upload/done/select" button.
     *
     * This is intentionally generic and WILL need tuning for the exact app
     * you point it at, since every app labels/structures its UI differently.
     */
    fun uploadFirstGalleryImage() {
        val root = rootInActiveWindow ?: return

        val firstImageNode = findFirstClickableImage(root)
        firstImageNode?.let { tapNode(it) }

        // Give the UI a moment, then look for a confirm/upload button.
        val confirmNode = findNodeByAnyText(root, listOf("Done", "Next", "Upload", "Post", "Share"))
        confirmNode?.let { tapNode(it) }
    }

    private fun findFirstClickableImage(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.className?.contains("ImageView") == true && node.isClickable) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findFirstClickableImage(child)
            if (result != null) return result
        }
        return null
    }

    private fun findNodeByAnyText(
        node: AccessibilityNodeInfo,
        options: List<String>
    ): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: node.contentDescription?.toString()
        if (nodeText != null && options.any { nodeText.equals(it, ignoreCase = true) }) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeByAnyText(child, options)
            if (result != null) return result
        }
        return null
    }

    private fun tapNode(node: AccessibilityNodeInfo) {
        if (node.isClickable) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return
        }
        // Fallback: dispatch a gesture tap at the node's screen coordinates.
        val rect = android.graphics.Rect()
        node.getBoundsInScreen(rect)
        val path = Path().apply { moveTo(rect.centerX().toFloat(), rect.centerY().toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Generic helper you can call from CommandProcessor to open any app by
     * package name via a launch intent (kept here too for convenience).
     */
    fun tapByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return findNodeByAnyText(root, listOf(text))?.let { tapNode(it); true } ?: false
    }
}
